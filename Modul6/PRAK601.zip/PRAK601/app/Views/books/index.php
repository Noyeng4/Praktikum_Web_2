<?= $this->extend('layouts/main') ?>
<?= $this->section('content') ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Daftar Buku</title>
    <style>
        body {
            background-color: #e9ecef;
            color: #343a40;
        }
        .list-group {
            margin: 50px auto;
            width: 75%;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        h1 {
            background-color: #198c9e;
            color: #ffffff;
            padding: 20px 0;
            margin: 0;
            text-align: center;
        }
        .table-responsive {
            padding: 20px;
        }
        table.table {
            margin-bottom: 0;
        }
        .btn-primary,
        .btn-warning,
        .btn-danger {
            border-color: #17a2b8;
            background-color: #17a2b8;
            color: #ffffff;
        }
        .btn-primary:hover,
        .btn-warning:hover,
        .btn-danger:hover {
            background-color: #138496;
            border-color: #138496;
        }
        .btn-warning {
            background-color: #28a745;
        }
        .btn-danger {
            background-color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="list-group">
        <h1>Daftar Buku</h1>
        <div class="table-responsive">
            <table class="table">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Judul Buku</th>
                        <th>Penulis</th>
                        <th>Penerbit</th>
                        <th>Tahun Terbit</th>
                        <th colspan="2">Opsi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($books as $book) : ?>
                        <tr>
                            <td><?= $book['id'] ?></td>
                            <td><?= $book['judul'] ?></td>
                            <td><?= $book['penulis'] ?></td>
                            <td><?= $book['penerbit'] ?></td>
                            <td><?= $book['tahun_terbit'] ?></td>
                            <td><a href="<?= base_url('books/edit/' . $book['id']) ?>" class="btn btn-warning">Edit</a></td>
                            <td><a href="<?= base_url('books/delete/' . $book['id']) ?>" class="btn btn-danger" onclick="return confirm('Apakah Anda yakin ingin menghapus data ini?');">Hapus</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="mt-3">
                <a href="<?= base_url('books/create') ?>" class="btn btn-primary float-end">Tambah Buku Baru</a>
                <a href="<?= base_url('dashboard') ?>" class="btn btn-primary">Kembali</a>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>
</html>
<?= $this->endSection() ?>