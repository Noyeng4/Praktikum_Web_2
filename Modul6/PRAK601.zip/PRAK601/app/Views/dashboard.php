<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <title>Welcome Page</title>
    <style>
        body {
            background-color: #e9ecef;
            color: #343a40;
        }
        .list-group {
            margin: 200px auto;
            width: 35%; /* Match width of Menu Index */
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        h1 {
            background-color: #198c9e;
            color: #ffffff;
            padding: 20px 0;
            margin: 0;
            text-align: center;
        }
        .list-group-item {
            border: none;
            background-color: #ffffff;
            color: #17a2b8;
            padding: 20px;
            font-size: 18px;
            text-decoration: none; /* Remove underline from links */
        }
        .list-group-item:hover {
            background-color: #17a2b8;
            color: #ffffff;
            transition: background-color 0.3s, color 0.3s;
        }
    </style>
</head>

<body>
    <div class="list-group">
        <h1>Welcome, <?= session()->name ?></h1>
        <a href="<?= base_url('books');?>" class="list-group-item list-group-item-action">Kelola Buku</a>
        <a href="<?= base_url('logout');?>" class="list-group-item list-group-item-action">Logout</a>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</body>

</html>
